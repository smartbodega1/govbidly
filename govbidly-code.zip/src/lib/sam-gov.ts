import { SamGovResponse, SamGovOpportunity, Contract } from "@/types";

const SAM_GOV_BASE_URL = "https://api.sam.gov/opportunities/v2/search";

interface FetchOptions {
  keyword?: string;
  postedFrom?: string; // MM/dd/yyyy
  postedTo?: string;
  naicsCode?: string;
  setAside?: string;
  state?: string;
  noticeType?: string;
  limit?: number;
  offset?: number;
}

export async function fetchSamGovOpportunities(
  options: FetchOptions
): Promise<SamGovResponse> {
  const params = new URLSearchParams({
    api_key: process.env.SAM_GOV_API_KEY!,
    limit: String(options.limit || 100),
    offset: String(options.offset || 0),
    postedFrom: options.postedFrom || getDateDaysAgo(30),
    postedTo: options.postedTo || getTodayFormatted(),
  });

  if (options.keyword) params.set("keyword", options.keyword);
  if (options.naicsCode) params.set("naicsCode", options.naicsCode);
  if (options.setAside) params.set("setAside", options.setAside);
  if (options.state) params.set("state", options.state);
  if (options.noticeType) params.set("noticeType", options.noticeType);

  const response = await fetch(`${SAM_GOV_BASE_URL}?${params.toString()}`, {
    headers: { Accept: "application/json" },
    next: { revalidate: 3600 }, // Cache for 1 hour
  });

  if (!response.ok) {
    throw new Error(`sam.gov API error: ${response.status} ${response.statusText}`);
  }

  return response.json();
}

export function mapSamGovToContract(opp: SamGovOpportunity): Omit<Contract, "id" | "created_at" | "updated_at"> {
  const primaryContact = opp.pointOfContact?.[0];

  return {
    notice_id: opp.noticeId,
    title: opp.title,
    description: opp.description || "",
    sol_number: opp.solicitationNumber || null,
    department: opp.fullParentPathName?.split(".")?.shift() || null,
    sub_tier: opp.fullParentPathName?.split(".")?.slice(1, 2)?.join("") || null,
    office: opp.fullParentPathName?.split(".")?.pop() || null,
    posted_date: opp.postedDate,
    response_deadline: opp.responseDeadLine || null,
    type: opp.type || opp.baseType || "Unknown",
    set_aside: opp.setAsideDescription || opp.setAsideCode || null,
    naics_code: opp.naicsCode || null,
    naics_description: opp.naicsSolicitationDescription || null,
    classification_code: opp.classificationCode || null,
    place_of_performance_state: opp.placeOfPerformance?.state?.code || null,
    place_of_performance_city: opp.placeOfPerformance?.city?.name || null,
    award_amount: opp.award?.amount ? parseFloat(opp.award.amount) : null,
    point_of_contact_name: primaryContact?.fullName || null,
    point_of_contact_email: primaryContact?.email || null,
    link: opp.link?.href || `https://sam.gov/opp/${opp.noticeId}/view`,
    active: opp.active === "Yes",
  };
}

function getTodayFormatted(): string {
  const d = new Date();
  return `${String(d.getMonth() + 1).padStart(2, "0")}/${String(d.getDate()).padStart(2, "0")}/${d.getFullYear()}`;
}

function getDateDaysAgo(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return `${String(d.getMonth() + 1).padStart(2, "0")}/${String(d.getDate()).padStart(2, "0")}/${d.getFullYear()}`;
}
