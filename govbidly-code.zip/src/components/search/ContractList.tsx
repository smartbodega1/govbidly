"use client";

import { ContractSearchResult } from "@/types";
import { ContractCard } from "./ContractCard";
import { ChevronLeft, ChevronRight, FileSearch } from "lucide-react";

interface ContractListProps {
  results: ContractSearchResult | null;
  loading: boolean;
  error: string | null;
  onPageChange: (page: number) => void;
}

export function ContractList({ results, loading, error, onPageChange }: ContractListProps) {
  // Loading state
  if (loading) {
    return (
      <div className="space-y-4">
        {[...Array(5)].map((_, i) => (
          <div key={i} className="card animate-pulse p-6">
            <div className="h-4 w-3/4 rounded bg-dark-700" />
            <div className="mt-3 h-3 w-1/2 rounded bg-dark-700" />
            <div className="mt-4 h-3 w-full rounded bg-dark-700" />
            <div className="mt-2 h-3 w-5/6 rounded bg-dark-700" />
            <div className="mt-4 flex gap-2">
              <div className="h-6 w-20 rounded-full bg-dark-700" />
              <div className="h-6 w-16 rounded-full bg-dark-700" />
              <div className="h-6 w-24 rounded-full bg-dark-700" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="card p-12 text-center">
        <p className="text-red-400 font-medium">{error}</p>
        <p className="mt-2 text-sm text-dark-400">Please try again or adjust your filters.</p>
      </div>
    );
  }

  // Empty / initial state
  if (!results) {
    return (
      <div className="card p-12 text-center">
        <FileSearch className="mx-auto h-12 w-12 text-dark-500" />
        <h3 className="mt-4 text-lg font-semibold text-white">
          Search for Government Contracts
        </h3>
        <p className="mt-2 text-sm text-dark-400">
          Use the filters on the left to find federal contracting opportunities.
          Start by selecting a state or entering a keyword.
        </p>
      </div>
    );
  }

  // No results
  if (results.contracts.length === 0) {
    return (
      <div className="card p-12 text-center">
        <FileSearch className="mx-auto h-12 w-12 text-dark-500" />
        <h3 className="mt-4 text-lg font-semibold text-white">No Contracts Found</h3>
        <p className="mt-2 text-sm text-dark-400">
          Try broadening your search — remove filters or use different keywords.
        </p>
      </div>
    );
  }

  return (
    <div>
      {/* Results header */}
      <div className="mb-4 flex items-center justify-between">
        <p className="text-sm text-dark-400">
          Showing{" "}
          <span className="font-medium text-white">
            {(results.page - 1) * results.per_page + 1}–
            {Math.min(results.page * results.per_page, results.total)}
          </span>{" "}
          of <span className="font-medium text-white">{results.total.toLocaleString()}</span> contracts
        </p>
      </div>

      {/* Contract cards */}
      <div className="space-y-4">
        {results.contracts.map((contract) => (
          <ContractCard key={contract.id} contract={contract} />
        ))}
      </div>

      {/* Pagination */}
      {results.total_pages > 1 && (
        <div className="mt-8 flex items-center justify-center gap-2">
          <button
            onClick={() => onPageChange(results.page - 1)}
            disabled={results.page <= 1}
            className="btn-ghost disabled:opacity-30"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>

          {Array.from({ length: Math.min(results.total_pages, 7) }, (_, i) => {
            let page: number;
            if (results.total_pages <= 7) {
              page = i + 1;
            } else if (results.page <= 4) {
              page = i + 1;
            } else if (results.page >= results.total_pages - 3) {
              page = results.total_pages - 6 + i;
            } else {
              page = results.page - 3 + i;
            }

            return (
              <button
                key={page}
                onClick={() => onPageChange(page)}
                className={`flex h-9 w-9 items-center justify-center rounded-lg text-sm font-medium transition-colors ${
                  page === results.page
                    ? "bg-brand-600 text-white"
                    : "text-dark-400 hover:bg-dark-700 hover:text-white"
                }`}
              >
                {page}
              </button>
            );
          })}

          <button
            onClick={() => onPageChange(results.page + 1)}
            disabled={results.page >= results.total_pages}
            className="btn-ghost disabled:opacity-30"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>
      )}
    </div>
  );
}
