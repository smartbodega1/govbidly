"use client";

import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

const faqs = [
  {
    q: "What is SAM.gov?",
    a: "SAM.gov (System for Award Management) is the official U.S. government website for federal contracting opportunities. All federal agencies post their contract opportunities there. It's free to use but notoriously difficult to navigate.",
  },
  {
    q: "How is GovBidly different from SAM.gov?",
    a: "We pull data directly from SAM.gov daily and present it in a clean, searchable interface. We add smart filters, email alerts, saved searches, and analytics that SAM.gov doesn't offer. Think of us as the user-friendly layer on top of SAM.gov.",
  },
  {
    q: "Do I need a SAM.gov registration to use GovBidly?",
    a: "No! You can search and discover contracts without any SAM.gov registration. However, to actually bid on a contract, you'll need to be registered on SAM.gov and have a UEI number.",
  },
  {
    q: "What's included in the free trial?",
    a: "You get full access to all features for 5 days — unlimited searches, email alerts, saved searches, everything. No credit card required to start.",
  },
  {
    q: "What are set-aside contracts?",
    a: "Set-aside contracts are reserved for specific types of small businesses: 8(a), HUBZone, Service-Disabled Veteran-Owned (SDVOSB), Women-Owned (WOSB), and more. The government sets aside about 23% of all contracting dollars for small businesses.",
  },
  {
    q: "How often is the data updated?",
    a: "We sync with SAM.gov every day. You'll see new opportunities within 24 hours of them being posted on SAM.gov.",
  },
  {
    q: "Can I cancel anytime?",
    a: "Yes. Cancel your subscription at any time with one click. No long-term commitments, no cancellation fees.",
  },
];

export function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section className="border-t border-dark-700 bg-dark-950 py-20" id="faq">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-brand-400">
            FAQ
          </p>
          <h2 className="section-heading mt-3">Frequently Asked Questions</h2>
        </div>

        <div className="mt-12 space-y-4">
          {faqs.map((faq, i) => (
            <div key={i} className="card overflow-hidden">
              <button
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
                className="flex w-full items-center justify-between p-5 text-left"
              >
                <span className="text-sm font-semibold text-white">{faq.q}</span>
                <ChevronDown
                  className={cn(
                    "h-4 w-4 shrink-0 text-dark-400 transition-transform",
                    openIndex === i && "rotate-180"
                  )}
                />
              </button>
              {openIndex === i && (
                <div className="border-t border-dark-700 px-5 pb-5 pt-3">
                  <p className="text-sm text-dark-400 leading-relaxed">{faq.a}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
