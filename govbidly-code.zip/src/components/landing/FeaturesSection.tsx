import {
  Search,
  Bell,
  Filter,
  Zap,
  BarChart3,
  Shield,
} from "lucide-react";

const features = [
  {
    icon: Search,
    title: "Powerful Search",
    description:
      "Search by keyword, NAICS code, set-aside type, state, dollar amount, and more. Find exactly what you're looking for in seconds.",
  },
  {
    icon: Filter,
    title: "Smart Filters",
    description:
      "Filter by business type (8(a), HUBZone, SDVOSB, WOSB), location, notice type, and deadline. Drill down to your niche.",
  },
  {
    icon: Bell,
    title: "Email Alerts",
    description:
      "Save your searches and get notified the moment new contracts match your criteria. Never miss an opportunity again.",
  },
  {
    icon: Zap,
    title: "Updated Daily",
    description:
      "Our database syncs with SAM.gov every day. You always see the freshest opportunities, without hitting API limits.",
  },
  {
    icon: BarChart3,
    title: "Contract Analytics",
    description:
      "See trends in your industry — which agencies are spending, average contract values, and where the money is flowing.",
  },
  {
    icon: Shield,
    title: "Built for Small Business",
    description:
      "Designed specifically for small businesses trying to break into government contracting. No enterprise bloat.",
  },
];

export function FeaturesSection() {
  return (
    <section className="py-20" id="features">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-brand-400">
            Features
          </p>
          <h2 className="section-heading mt-3">
            Everything You Need to <span className="gradient-text">Win Contracts</span>
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-dark-400">
            We took the pain out of SAM.gov and built the tool every small business 
            owner wishes existed.
          </p>
        </div>

        <div className="mt-16 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature) => (
            <div key={feature.title} className="card-hover p-6">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-brand-500/10">
                <feature.icon className="h-5 w-5 text-brand-400" />
              </div>
              <h3 className="mt-4 text-lg font-semibold text-white">
                {feature.title}
              </h3>
              <p className="mt-2 text-sm text-dark-400">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
