import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatDate(date: string): string {
  return new Date(date).toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

export function daysUntil(date: string): number {
  const now = new Date();
  const target = new Date(date);
  const diff = target.getTime() - now.getTime();
  return Math.ceil(diff / (1000 * 60 * 60 * 24));
}

export function truncate(str: string, length: number): string {
  if (str.length <= length) return str;
  return str.substring(0, length) + "...";
}

export function getSetAsideLabel(code: string): string {
  const labels: Record<string, string> = {
    SBA: "Small Business",
    SBP: "Partial SB",
    "8A": "8(a)",
    "8AN": "8(a) Sole Source",
    HZC: "HUBZone",
    HZS: "HUBZone SS",
    SDVOSBC: "SDVOSB",
    SDVOSBS: "SDVOSB SS",
    WOSB: "WOSB",
    WOSBSS: "WOSB SS",
    EDWOSB: "EDWOSB",
    EDWOSBSS: "EDWOSB SS",
    VSA: "Veteran",
    VSS: "Veteran SS",
  };
  return labels[code] || code;
}

export function getNoticeTypeColor(type: string): string {
  const colors: Record<string, string> = {
    Solicitation: "bg-green-500/10 text-green-400 border-green-500/20",
    "Pre-Solicitation": "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
    "Combined Synopsis/Solicitation": "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
    "Sources Sought": "bg-blue-500/10 text-blue-400 border-blue-500/20",
    "Special Notice": "bg-purple-500/10 text-purple-400 border-purple-500/20",
    "Award Notice": "bg-cyan-500/10 text-cyan-400 border-cyan-500/20",
    "Intent to Bundle": "bg-orange-500/10 text-orange-400 border-orange-500/20",
  };
  return colors[type] || "bg-gray-500/10 text-gray-400 border-gray-500/20";
}
