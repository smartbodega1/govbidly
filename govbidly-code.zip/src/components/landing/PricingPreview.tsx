"use client";

import { useState } from "react";
import Link from "next/link";
import { Check, ArrowRight } from "lucide-react";
import { PRICING_TIERS } from "@/lib/constants";
import { cn } from "@/lib/utils";

export function PricingPreview() {
  const [annual, setAnnual] = useState(false);

  return (
    <section className="py-20" id="pricing">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-brand-400">
            Pricing
          </p>
          <h2 className="section-heading mt-3">
            Simple, Transparent Pricing
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-dark-400">
            Start with a 5-day free trial. Pick the plan that fits your business.
            Save 17% with annual billing.
          </p>

          {/* Toggle */}
          <div className="mt-8 flex items-center justify-center gap-3">
            <span className={cn("text-sm", !annual ? "text-white" : "text-dark-400")}>
              Monthly
            </span>
            <button
              onClick={() => setAnnual(!annual)}
              className={cn(
                "relative h-6 w-11 rounded-full transition-colors",
                annual ? "bg-brand-600" : "bg-dark-600"
              )}
            >
              <span
                className={cn(
                  "absolute top-0.5 left-0.5 h-5 w-5 rounded-full bg-white transition-transform",
                  annual && "translate-x-5"
                )}
              />
            </button>
            <span className={cn("text-sm", annual ? "text-white" : "text-dark-400")}>
              Annual
              <span className="ml-1 rounded-full bg-green-500/10 px-2 py-0.5 text-xs text-green-400">
                Save 17%
              </span>
            </span>
          </div>
        </div>

        <div className="mt-12 grid gap-8 lg:grid-cols-3">
          {PRICING_TIERS.map((tier) => (
            <div
              key={tier.name}
              className={cn(
                "card relative flex flex-col p-8",
                tier.popular && "border-brand-500 ring-1 ring-brand-500/50"
              )}
            >
              {tier.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-brand-600 px-4 py-1 text-xs font-semibold text-white">
                  Most Popular
                </div>
              )}

              <h3 className="text-xl font-bold text-white">{tier.name}</h3>
              <div className="mt-4">
                <span className="text-4xl font-extrabold text-white">
                  ${annual ? Math.round(tier.annualPrice / 12) : tier.monthlyPrice}
                </span>
                <span className="text-dark-400">/month</span>
                {annual && (
                  <p className="mt-1 text-sm text-dark-500">
                    ${tier.annualPrice}/year (billed annually)
                  </p>
                )}
              </div>

              <ul className="mt-8 flex-1 space-y-3">
                {tier.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-3 text-sm text-dark-300">
                    <Check className="h-4 w-4 shrink-0 text-brand-400 mt-0.5" />
                    {feature}
                  </li>
                ))}
              </ul>

              <Link
                href="/signup"
                className={cn(
                  "mt-8 w-full text-center group",
                  tier.popular ? "btn-primary" : "btn-secondary"
                )}
              >
                Start Free Trial
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
