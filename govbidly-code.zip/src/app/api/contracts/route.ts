import { NextRequest, NextResponse } from "next/server";
import { createServiceClient } from "@/lib/supabase/server";
import { ContractSearchResult } from "@/types";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);

    const query = searchParams.get("query") || "";
    const state = searchParams.get("state") || "";
    const naicsCode = searchParams.get("naics_code") || "";
    const setAside = searchParams.get("set_aside") || "";
    const type = searchParams.get("type") || "";
    const minAmount = searchParams.get("min_amount");
    const maxAmount = searchParams.get("max_amount");
    const page = parseInt(searchParams.get("page") || "1", 10);
    const perPage = Math.min(parseInt(searchParams.get("per_page") || "20", 10), 50);

    const supabase = createServiceClient();
    const offset = (page - 1) * perPage;

    // Build query
    let dbQuery = supabase
      .from("contracts")
      .select("*", { count: "exact" })
      .eq("active", true)
      .order("posted_date", { ascending: false })
      .range(offset, offset + perPage - 1);

    // Apply filters
    if (query) {
      dbQuery = dbQuery.textSearch("fts", query, { type: "websearch" });
    }

    if (state) {
      dbQuery = dbQuery.eq("place_of_performance_state", state);
    }

    if (naicsCode) {
      dbQuery = dbQuery.eq("naics_code", naicsCode);
    }

    if (setAside) {
      dbQuery = dbQuery.ilike("set_aside", `%${setAside}%`);
    }

    if (type) {
      dbQuery = dbQuery.eq("type", type);
    }

    if (minAmount) {
      dbQuery = dbQuery.gte("award_amount", Number(minAmount));
    }

    if (maxAmount) {
      dbQuery = dbQuery.lte("award_amount", Number(maxAmount));
    }

    const { data, count, error } = await dbQuery;

    if (error) {
      console.error("Supabase query error:", error);
      return NextResponse.json(
        { error: "Failed to search contracts" },
        { status: 500 }
      );
    }

    const total = count || 0;
    const result: ContractSearchResult = {
      contracts: data || [],
      total,
      page,
      per_page: perPage,
      total_pages: Math.ceil(total / perPage),
    };

    return NextResponse.json(result);
  } catch (err) {
    console.error("Contract search error:", err);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
