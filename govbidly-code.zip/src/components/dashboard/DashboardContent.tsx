"use client";

import { UserProfile, SavedSearch, AlertNotification } from "@/types";
import { formatDate, daysUntil } from "@/lib/utils";
import { PRICING_TIERS } from "@/lib/constants";
import Link from "next/link";
import {
  Search,
  Bell,
  CreditCard,
  BookmarkCheck,
  Crown,
  Clock,
  ArrowRight,
  Plus,
  ToggleLeft,
  ToggleRight,
} from "lucide-react";

interface DashboardContentProps {
  profile: any;
  savedSearches: SavedSearch[];
  recentAlerts: AlertNotification[];
}

export function DashboardContent({
  profile,
  savedSearches,
  recentAlerts,
}: DashboardContentProps) {
  const currentTier = PRICING_TIERS.find((t) => t.tier === profile?.subscription_tier);
  const trialDaysLeft = profile?.trial_ends_at
    ? Math.max(0, daysUntil(profile.trial_ends_at))
    : 0;
  const isTrialing = profile?.subscription_status === "trialing";
  const isActive = profile?.subscription_status === "active" || isTrialing;

  return (
    <div>
      {/* Header */}
      <div className="mb-8 flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Dashboard</h1>
          <p className="mt-1 text-dark-400">
            Welcome back, {profile?.full_name || profile?.email}
          </p>
        </div>
        <Link href="/search" className="btn-primary">
          <Search className="mr-2 h-4 w-4" />
          Search Contracts
        </Link>
      </div>

      {/* Trial banner */}
      {isTrialing && trialDaysLeft > 0 && (
        <div className="mb-6 rounded-xl border border-brand-500/30 bg-brand-500/10 p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Clock className="h-5 w-5 text-brand-400" />
            <div>
              <p className="text-sm font-medium text-white">
                Free trial: {trialDaysLeft} day{trialDaysLeft !== 1 ? "s" : ""} remaining
              </p>
              <p className="text-xs text-dark-400">
                Upgrade to keep access after your trial ends.
              </p>
            </div>
          </div>
          <Link href="/pricing" className="btn-primary !py-2 !px-4 !text-xs">
            Upgrade Now
          </Link>
        </div>
      )}

      {/* Stats Grid */}
      <div className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="card p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-brand-500/10">
              <Crown className="h-5 w-5 text-brand-400" />
            </div>
            <div>
              <p className="text-xs text-dark-400">Plan</p>
              <p className="text-sm font-semibold text-white capitalize">
                {profile?.subscription_tier || "Free"}
                {isTrialing && " (Trial)"}
              </p>
            </div>
          </div>
        </div>

        <div className="card p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-500/10">
              <Search className="h-5 w-5 text-green-400" />
            </div>
            <div>
              <p className="text-xs text-dark-400">Searches Today</p>
              <p className="text-sm font-semibold text-white">
                {profile?.searches_today || 0}
                {currentTier && currentTier.limits.daily_searches > 0 && (
                  <span className="text-dark-400">
                    /{currentTier.limits.daily_searches}
                  </span>
                )}
              </p>
            </div>
          </div>
        </div>

        <div className="card p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-500/10">
              <BookmarkCheck className="h-5 w-5 text-purple-400" />
            </div>
            <div>
              <p className="text-xs text-dark-400">Saved Searches</p>
              <p className="text-sm font-semibold text-white">
                {savedSearches.length}
              </p>
            </div>
          </div>
        </div>

        <div className="card p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-yellow-500/10">
              <Bell className="h-5 w-5 text-yellow-400" />
            </div>
            <div>
              <p className="text-xs text-dark-400">Alerts Sent</p>
              <p className="text-sm font-semibold text-white">
                {recentAlerts.length}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Two column layout */}
      <div className="grid gap-8 lg:grid-cols-2">
        {/* Saved Searches */}
        <div className="card">
          <div className="flex items-center justify-between border-b border-dark-700 p-5">
            <h2 className="text-sm font-semibold text-white flex items-center gap-2">
              <BookmarkCheck className="h-4 w-4 text-brand-400" />
              Saved Searches
            </h2>
            <Link href="/search" className="text-xs text-brand-400 hover:text-brand-300 flex items-center gap-1">
              <Plus className="h-3 w-3" />
              New Search
            </Link>
          </div>

          {savedSearches.length === 0 ? (
            <div className="p-8 text-center">
              <Search className="mx-auto h-8 w-8 text-dark-500" />
              <p className="mt-3 text-sm text-dark-400">No saved searches yet.</p>
              <Link href="/search" className="mt-3 inline-block text-sm text-brand-400 hover:text-brand-300">
                Create your first search →
              </Link>
            </div>
          ) : (
            <div className="divide-y divide-dark-700">
              {savedSearches.map((search) => (
                <div key={search.id} className="flex items-center justify-between p-4 hover:bg-dark-800/50 transition-colors">
                  <div>
                    <p className="text-sm font-medium text-white">{search.name}</p>
                    <p className="text-xs text-dark-400">
                      Created {formatDate(search.created_at)}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    {search.alert_enabled ? (
                      <span className="flex items-center gap-1 text-xs text-green-400">
                        <ToggleRight className="h-4 w-4" />
                        Alerts on
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-xs text-dark-500">
                        <ToggleLeft className="h-4 w-4" />
                        Alerts off
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent Alerts */}
        <div className="card">
          <div className="border-b border-dark-700 p-5">
            <h2 className="text-sm font-semibold text-white flex items-center gap-2">
              <Bell className="h-4 w-4 text-yellow-400" />
              Recent Alerts
            </h2>
          </div>

          {recentAlerts.length === 0 ? (
            <div className="p-8 text-center">
              <Bell className="mx-auto h-8 w-8 text-dark-500" />
              <p className="mt-3 text-sm text-dark-400">No alerts yet.</p>
              <p className="text-xs text-dark-500 mt-1">
                Save a search and enable alerts to get notified.
              </p>
            </div>
          ) : (
            <div className="divide-y divide-dark-700">
              {recentAlerts.map((alert) => (
                <div key={alert.id} className="p-4 hover:bg-dark-800/50 transition-colors">
                  <div className="flex items-center justify-between">
                    <p className="text-sm text-white">
                      {alert.contracts.length} contract{alert.contracts.length !== 1 ? "s" : ""} found
                    </p>
                    <p className="text-xs text-dark-400">
                      {alert.sent_at ? formatDate(alert.sent_at) : "Pending"}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Upgrade CTA for free users */}
      {!isActive && (
        <div className="mt-8 card p-8 text-center">
          <CreditCard className="mx-auto h-10 w-10 text-brand-400" />
          <h3 className="mt-4 text-lg font-semibold text-white">
            Upgrade to Get Full Access
          </h3>
          <p className="mt-2 text-sm text-dark-400">
            Unlimited searches, email alerts, and more. Plans start at $29/month.
          </p>
          <Link href="/pricing" className="btn-primary mt-6 group">
            View Plans
            <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </div>
      )}
    </div>
  );
}
