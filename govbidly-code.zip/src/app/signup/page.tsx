import { Metadata } from "next";
import { AuthForm } from "@/components/ui/AuthForm";

export const metadata: Metadata = {
  title: "Start Your Free Trial",
  description: "Create your GovBidly account. 5-day free trial with full access.",
};

export default function SignupPage() {
  return (
    <div className="flex min-h-[calc(100vh-10rem)] items-center justify-center px-4">
      <AuthForm mode="signup" />
    </div>
  );
}
