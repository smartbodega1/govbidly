"use client";

import { useState, useCallback } from "react";
import { SearchFilters } from "./SearchFilters";
import { ContractList } from "./ContractList";
import { ContractFilters, ContractSearchResult } from "@/types";

export function SearchInterface() {
  const [results, setResults] = useState<ContractSearchResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [filters, setFilters] = useState<ContractFilters>({
    page: 1,
    per_page: 20,
  });

  const handleSearch = useCallback(async (newFilters: ContractFilters) => {
    setLoading(true);
    setError(null);
    const mergedFilters = { ...filters, ...newFilters, page: newFilters.page || 1 };
    setFilters(mergedFilters);

    try {
      const params = new URLSearchParams();
      Object.entries(mergedFilters).forEach(([key, value]) => {
        if (value !== undefined && value !== "" && value !== null) {
          params.set(key, String(value));
        }
      });

      const res = await fetch(`/api/contracts?${params.toString()}`);
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Search failed");
      }
      const data: ContractSearchResult = await res.json();
      setResults(data);
    } catch (err: any) {
      setError(err.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  }, [filters]);

  const handlePageChange = (page: number) => {
    handleSearch({ ...filters, page });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="grid gap-6 lg:grid-cols-[320px_1fr]">
      <aside>
        <SearchFilters onSearch={handleSearch} loading={loading} />
      </aside>
      <main>
        <ContractList
          results={results}
          loading={loading}
          error={error}
          onPageChange={handlePageChange}
        />
      </main>
    </div>
  );
}
