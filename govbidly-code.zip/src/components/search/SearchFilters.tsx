"use client";

import { useState } from "react";
import { Search, SlidersHorizontal, RotateCcw } from "lucide-react";
import { ContractFilters } from "@/types";
import { US_STATES, SET_ASIDE_TYPES, NOTICE_TYPES, COMMON_NAICS } from "@/lib/constants";

interface SearchFiltersProps {
  onSearch: (filters: ContractFilters) => void;
  loading: boolean;
}

export function SearchFilters({ onSearch, loading }: SearchFiltersProps) {
  const [query, setQuery] = useState("");
  const [state, setState] = useState("");
  const [naicsCode, setNaicsCode] = useState("");
  const [setAside, setSetAside] = useState("");
  const [type, setType] = useState("");
  const [minAmount, setMinAmount] = useState("");
  const [maxAmount, setMaxAmount] = useState("");
  const [showAdvanced, setShowAdvanced] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch({
      query: query || undefined,
      state: state || undefined,
      naics_code: naicsCode || undefined,
      set_aside: setAside || undefined,
      type: type || undefined,
      min_amount: minAmount ? Number(minAmount) : undefined,
      max_amount: maxAmount ? Number(maxAmount) : undefined,
    });
  };

  const handleReset = () => {
    setQuery("");
    setState("");
    setNaicsCode("");
    setSetAside("");
    setType("");
    setMinAmount("");
    setMaxAmount("");
  };

  return (
    <form onSubmit={handleSubmit} className="card sticky top-20 p-5 space-y-5">
      <div className="flex items-center justify-between">
        <h2 className="flex items-center gap-2 text-sm font-semibold text-white">
          <SlidersHorizontal className="h-4 w-4" />
          Filters
        </h2>
        <button
          type="button"
          onClick={handleReset}
          className="flex items-center gap-1 text-xs text-dark-400 hover:text-white transition-colors"
        >
          <RotateCcw className="h-3 w-3" />
          Reset
        </button>
      </div>

      {/* Keyword Search */}
      <div>
        <label className="mb-1.5 block text-xs font-medium text-dark-300">
          Keyword
        </label>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-dark-400" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="e.g. cybersecurity, janitorial..."
            className="input-field !pl-10"
          />
        </div>
      </div>

      {/* State */}
      <div>
        <label className="mb-1.5 block text-xs font-medium text-dark-300">
          State / Territory
        </label>
        <select
          value={state}
          onChange={(e) => setState(e.target.value)}
          className="input-field"
        >
          <option value="">All States</option>
          {US_STATES.map((s) => (
            <option key={s.code} value={s.code}>
              {s.name}
            </option>
          ))}
        </select>
      </div>

      {/* Set-Aside */}
      <div>
        <label className="mb-1.5 block text-xs font-medium text-dark-300">
          Set-Aside Type
        </label>
        <select
          value={setAside}
          onChange={(e) => setSetAside(e.target.value)}
          className="input-field"
        >
          <option value="">All Types</option>
          {SET_ASIDE_TYPES.map((s) => (
            <option key={s.code} value={s.code}>
              {s.name}
            </option>
          ))}
        </select>
      </div>

      {/* NAICS Code */}
      <div>
        <label className="mb-1.5 block text-xs font-medium text-dark-300">
          NAICS Code
        </label>
        <select
          value={naicsCode}
          onChange={(e) => setNaicsCode(e.target.value)}
          className="input-field"
        >
          <option value="">All Industries</option>
          {COMMON_NAICS.map((n) => (
            <option key={n.code} value={n.code}>
              {n.code} — {n.name}
            </option>
          ))}
        </select>
      </div>

      {/* Notice Type */}
      <div>
        <label className="mb-1.5 block text-xs font-medium text-dark-300">
          Notice Type
        </label>
        <select
          value={type}
          onChange={(e) => setType(e.target.value)}
          className="input-field"
        >
          <option value="">All Notices</option>
          {NOTICE_TYPES.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>
      </div>

      {/* Advanced Toggle */}
      <button
        type="button"
        onClick={() => setShowAdvanced(!showAdvanced)}
        className="text-xs text-brand-400 hover:text-brand-300 transition-colors"
      >
        {showAdvanced ? "Hide" : "Show"} advanced filters
      </button>

      {showAdvanced && (
        <div className="space-y-5 border-t border-dark-700 pt-5">
          {/* Amount Range */}
          <div>
            <label className="mb-1.5 block text-xs font-medium text-dark-300">
              Award Amount Range
            </label>
            <div className="flex gap-2">
              <input
                type="number"
                value={minAmount}
                onChange={(e) => setMinAmount(e.target.value)}
                placeholder="Min ($)"
                className="input-field"
              />
              <input
                type="number"
                value={maxAmount}
                onChange={(e) => setMaxAmount(e.target.value)}
                placeholder="Max ($)"
                className="input-field"
              />
            </div>
          </div>
        </div>
      )}

      {/* Submit */}
      <button
        type="submit"
        disabled={loading}
        className="btn-primary w-full"
      >
        {loading ? (
          <span className="flex items-center gap-2">
            <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
            Searching...
          </span>
        ) : (
          <span className="flex items-center gap-2">
            <Search className="h-4 w-4" />
            Search Contracts
          </span>
        )}
      </button>
    </form>
  );
}
