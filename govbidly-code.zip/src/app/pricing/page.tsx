import { Metadata } from "next";
import { PricingPreview } from "@/components/landing/PricingPreview";

export const metadata: Metadata = {
  title: "Pricing — Plans That Fit Your Business",
  description:
    "Choose from Starter ($29/mo), Pro ($49/mo), or Agency ($99/mo) plans. 5-day free trial included. Find government contracts faster.",
};

export default function PricingPage() {
  return (
    <div className="py-8">
      <PricingPreview />

      {/* Comparison table */}
      <section className="mx-auto max-w-4xl px-4 pb-20 sm:px-6 lg:px-8">
        <h3 className="mb-8 text-center text-2xl font-bold text-white">
          Compare Plans
        </h3>
        <div className="card overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-dark-700 bg-dark-800">
                <th className="p-4 text-left font-medium text-dark-300">Feature</th>
                <th className="p-4 text-center font-medium text-dark-300">Starter</th>
                <th className="p-4 text-center font-medium text-brand-400">Pro</th>
                <th className="p-4 text-center font-medium text-dark-300">Agency</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-dark-700">
              {[
                ["Daily searches", "25", "Unlimited", "Unlimited"],
                ["States", "1", "All 50+", "All 50+"],
                ["Saved searches", "3", "25", "Unlimited"],
                ["Email alerts", "✓", "✓ Priority", "✓ Priority"],
                ["Advanced filters", "—", "✓", "✓"],
                ["API access", "—", "—", "✓"],
                ["Team members", "1", "1", "Up to 10"],
                ["Contract analytics", "—", "—", "✓"],
                ["Support", "Email", "Priority", "Dedicated"],
              ].map(([feature, starter, pro, agency]) => (
                <tr key={feature} className="hover:bg-dark-800/50 transition-colors">
                  <td className="p-4 text-white">{feature}</td>
                  <td className="p-4 text-center text-dark-400">{starter}</td>
                  <td className="p-4 text-center text-white font-medium">{pro}</td>
                  <td className="p-4 text-center text-dark-400">{agency}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
