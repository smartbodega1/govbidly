import { UserPlus, Search, Bell, Trophy } from "lucide-react";

const steps = [
  {
    icon: UserPlus,
    step: "01",
    title: "Sign Up Free",
    description: "Create your account in 30 seconds. Get a 5-day free trial with full access — no credit card needed.",
  },
  {
    icon: Search,
    step: "02",
    title: "Search & Filter",
    description: "Use our powerful filters to find contracts that match your business profile, industry, and location.",
  },
  {
    icon: Bell,
    step: "03",
    title: "Save & Get Alerts",
    description: "Save your favorite searches and enable alerts. We'll email you when new matching contracts are posted.",
  },
  {
    icon: Trophy,
    step: "04",
    title: "Win Contracts",
    description: "Respond to opportunities faster than your competition. Be first in line when new contracts drop.",
  },
];

export function HowItWorksSection() {
  return (
    <section className="border-t border-dark-700 bg-dark-950 py-20" id="how-it-works">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-brand-400">
            How It Works
          </p>
          <h2 className="section-heading mt-3">
            Four Steps to Your First Contract
          </h2>
        </div>

        <div className="mt-16 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {steps.map((step, i) => (
            <div key={step.title} className="relative text-center">
              {/* Connector line */}
              {i < steps.length - 1 && (
                <div className="absolute left-1/2 top-8 hidden h-0.5 w-full bg-gradient-to-r from-brand-500/50 to-transparent lg:block" />
              )}
              <div className="relative mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-brand-600/20 ring-1 ring-brand-500/30">
                <step.icon className="h-7 w-7 text-brand-400" />
                <span className="absolute -right-1 -top-1 flex h-6 w-6 items-center justify-center rounded-full bg-brand-600 text-xs font-bold text-white">
                  {step.step}
                </span>
              </div>
              <h3 className="mt-6 text-lg font-semibold text-white">{step.title}</h3>
              <p className="mt-2 text-sm text-dark-400">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
