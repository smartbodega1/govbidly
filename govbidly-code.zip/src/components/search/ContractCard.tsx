"use client";

import { Contract } from "@/types";
import { formatCurrency, formatDate, daysUntil, truncate, getNoticeTypeColor } from "@/lib/utils";
import { Calendar, MapPin, DollarSign, ExternalLink, Clock, Building2 } from "lucide-react";

interface ContractCardProps {
  contract: Contract;
}

export function ContractCard({ contract }: ContractCardProps) {
  const daysLeft = contract.response_deadline ? daysUntil(contract.response_deadline) : null;

  return (
    <div className="card-hover p-6">
      {/* Header row */}
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <span className={`badge ${getNoticeTypeColor(contract.type)}`}>
              {contract.type}
            </span>
            {contract.set_aside && (
              <span className="badge bg-purple-500/10 text-purple-400 border-purple-500/20">
                {contract.set_aside}
              </span>
            )}
            {daysLeft !== null && daysLeft >= 0 && daysLeft <= 7 && (
              <span className="badge bg-red-500/10 text-red-400 border-red-500/20">
                <Clock className="mr-1 h-3 w-3" />
                {daysLeft === 0 ? "Due today" : `${daysLeft}d left`}
              </span>
            )}
          </div>

          <h3 className="mt-2 text-base font-semibold text-white leading-snug">
            {contract.title}
          </h3>

          {contract.description && (
            <p className="mt-2 text-sm text-dark-400 leading-relaxed">
              {truncate(contract.description.replace(/<[^>]*>/g, ""), 200)}
            </p>
          )}
        </div>
      </div>

      {/* Metadata row */}
      <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-dark-400">
        {contract.department && (
          <span className="flex items-center gap-1.5">
            <Building2 className="h-3.5 w-3.5" />
            {truncate(contract.department, 40)}
          </span>
        )}
        {contract.place_of_performance_state && (
          <span className="flex items-center gap-1.5">
            <MapPin className="h-3.5 w-3.5" />
            {contract.place_of_performance_city
              ? `${contract.place_of_performance_city}, ${contract.place_of_performance_state}`
              : contract.place_of_performance_state}
          </span>
        )}
        {contract.award_amount && (
          <span className="flex items-center gap-1.5">
            <DollarSign className="h-3.5 w-3.5" />
            {formatCurrency(contract.award_amount)}
          </span>
        )}
        <span className="flex items-center gap-1.5">
          <Calendar className="h-3.5 w-3.5" />
          Posted {formatDate(contract.posted_date)}
        </span>
        {contract.response_deadline && (
          <span className="flex items-center gap-1.5">
            <Clock className="h-3.5 w-3.5" />
            Due {formatDate(contract.response_deadline)}
          </span>
        )}
        {contract.naics_code && (
          <span className="rounded bg-dark-700 px-1.5 py-0.5 text-dark-300">
            NAICS {contract.naics_code}
          </span>
        )}
      </div>

      {/* Action row */}
      <div className="mt-4 flex items-center justify-between border-t border-dark-700 pt-4">
        <div className="text-xs text-dark-500">
          {contract.sol_number && <span>Sol# {contract.sol_number}</span>}
        </div>
        <a
          href={contract.link}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1.5 text-sm font-medium text-brand-400 hover:text-brand-300 transition-colors"
        >
          View on SAM.gov
          <ExternalLink className="h-3.5 w-3.5" />
        </a>
      </div>
    </div>
  );
}
