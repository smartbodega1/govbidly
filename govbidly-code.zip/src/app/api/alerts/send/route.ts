import { NextRequest, NextResponse } from "next/server";
import { createServiceClient } from "@/lib/supabase/server";
import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY);

export async function POST(request: NextRequest) {
  try {
    // Verify cron secret
    const authHeader = request.headers.get("authorization");
    if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const supabase = createServiceClient();

    // Get all saved searches with alerts enabled
    const { data: savedSearches } = await supabase
      .from("saved_searches")
      .select(`
        *,
        profiles!inner (
          id, email, full_name, subscription_tier, subscription_status
        )
      `)
      .eq("alert_enabled", true)
      .in("profiles.subscription_status", ["active", "trialing"]);

    if (!savedSearches || savedSearches.length === 0) {
      return NextResponse.json({ sent: 0 });
    }

    let sentCount = 0;

    for (const search of savedSearches) {
      const profile = (search as any).profiles;
      const filters = search.filters as any;

      // Build query for matching contracts posted since last alert
      let query = supabase
        .from("contracts")
        .select("id, title, type, set_aside, place_of_performance_state, posted_date, link")
        .eq("active", true)
        .order("posted_date", { ascending: false })
        .limit(10);

      if (search.last_alerted_at) {
        query = query.gt("posted_date", search.last_alerted_at);
      } else {
        // First alert — show contracts from last 24h
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        query = query.gt("posted_date", yesterday.toISOString());
      }

      // Apply saved search filters
      if (filters.query) {
        query = query.textSearch("fts", filters.query, { type: "websearch" });
      }
      if (filters.state) {
        query = query.eq("place_of_performance_state", filters.state);
      }
      if (filters.naics_code) {
        query = query.eq("naics_code", filters.naics_code);
      }
      if (filters.set_aside) {
        query = query.ilike("set_aside", `%${filters.set_aside}%`);
      }

      const { data: contracts } = await query;

      if (!contracts || contracts.length === 0) {
        continue;
      }

      // Send email
      const contractList = contracts
        .map(
          (c) =>
            `• ${c.title}\n  Type: ${c.type} | State: ${c.place_of_performance_state || "N/A"}\n  View: ${c.link}`
        )
        .join("\n\n");

      try {
        await resend.emails.send({
          from: process.env.EMAIL_FROM || "GovBidly <alerts@govbidlyfinder.com>",
          to: profile.email,
          subject: `🔔 ${contracts.length} New Contract${contracts.length > 1 ? "s" : ""} Match "${search.name}"`,
          text: `Hi ${profile.full_name || "there"},\n\nWe found ${contracts.length} new contract${contracts.length > 1 ? "s" : ""} matching your saved search "${search.name}":\n\n${contractList}\n\nView all results: ${process.env.NEXT_PUBLIC_APP_URL}/search\n\nManage alerts: ${process.env.NEXT_PUBLIC_APP_URL}/dashboard\n\n— GovBidly`,
          html: generateAlertEmailHTML(
            profile.full_name || "there",
            search.name,
            contracts
          ),
        });

        // Update last alerted timestamp
        await supabase
          .from("saved_searches")
          .update({ last_alerted_at: new Date().toISOString() })
          .eq("id", search.id);

        // Log the alert
        await supabase.from("alert_logs").insert({
          user_id: profile.id,
          saved_search_id: search.id,
          contract_ids: contracts.map((c) => c.id),
        });

        sentCount++;
      } catch (emailErr) {
        console.error(`Failed to send alert to ${profile.email}:`, emailErr);
      }

      // Rate limit: wait 200ms between emails
      await new Promise((r) => setTimeout(r, 200));
    }

    return NextResponse.json({ sent: sentCount });
  } catch (err: any) {
    console.error("Alert send error:", err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

function generateAlertEmailHTML(
  name: string,
  searchName: string,
  contracts: any[]
): string {
  const rows = contracts
    .map(
      (c) => `
      <tr>
        <td style="padding:12px 16px;border-bottom:1px solid #1e293b;">
          <a href="${c.link}" style="color:#3b82f6;text-decoration:none;font-weight:600;font-size:14px;">${c.title}</a>
          <div style="margin-top:4px;font-size:12px;color:#94a3b8;">
            ${c.type} ${c.set_aside ? `• ${c.set_aside}` : ""} ${c.place_of_performance_state ? `• ${c.place_of_performance_state}` : ""}
          </div>
        </td>
      </tr>`
    )
    .join("");

  return `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#0f172a;font-family:Inter,system-ui,sans-serif;">
  <div style="max-width:600px;margin:0 auto;padding:40px 20px;">
    <div style="text-align:center;margin-bottom:32px;">
      <div style="display:inline-block;background:#2563eb;padding:8px 12px;border-radius:8px;">
        <span style="color:white;font-weight:bold;font-size:18px;">⚡ GovBidly</span>
      </div>
    </div>
    <div style="background:#1e293b;border-radius:12px;border:1px solid #334155;overflow:hidden;">
      <div style="padding:24px;">
        <h2 style="color:white;margin:0 0 8px;">🔔 New Contracts Found</h2>
        <p style="color:#94a3b8;margin:0;font-size:14px;">
          Hi ${name}, we found <strong style="color:white;">${contracts.length}</strong> new contract${contracts.length > 1 ? "s" : ""} matching "<strong style="color:#60a5fa;">${searchName}</strong>".
        </p>
      </div>
      <table style="width:100%;border-collapse:collapse;">
        ${rows}
      </table>
      <div style="padding:20px;text-align:center;">
        <a href="${process.env.NEXT_PUBLIC_APP_URL}/search" style="display:inline-block;background:#2563eb;color:white;padding:12px 32px;border-radius:8px;text-decoration:none;font-weight:600;font-size:14px;">
          View All Results →
        </a>
      </div>
    </div>
    <div style="text-align:center;margin-top:24px;font-size:12px;color:#475569;">
      <a href="${process.env.NEXT_PUBLIC_APP_URL}/dashboard" style="color:#475569;">Manage Alerts</a> •
      <a href="${process.env.NEXT_PUBLIC_APP_URL}" style="color:#475569;">GovBidly</a>
    </div>
  </div>
</body>
</html>`;
}
