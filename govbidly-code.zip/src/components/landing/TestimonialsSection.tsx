import { Star } from "lucide-react";

const testimonials = [
  {
    quote:
      "I used to spend 8 hours a week digging through SAM.gov. Now I find relevant contracts in 5 minutes. This tool pays for itself 100x over.",
    name: "Marcus Johnson",
    title: "Owner, Johnson IT Services",
    type: "8(a) Certified",
  },
  {
    quote:
      "The email alerts alone are worth the subscription. I won my first $150K contract because I was the first to respond — got the alert at 6AM.",
    name: "Lisa Chen",
    title: "CEO, Pacific Engineering Group",
    type: "WOSB",
  },
  {
    quote:
      "As a veteran-owned business, I needed a tool that filtered for SDVOSB set-asides. GovBidly makes it dead simple.",
    name: "James Williams",
    title: "Founder, Vanguard Security",
    type: "SDVOSB",
  },
];

export function TestimonialsSection() {
  return (
    <section className="border-t border-dark-700 bg-dark-950 py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-brand-400">
            Testimonials
          </p>
          <h2 className="section-heading mt-3">
            Trusted by Small Business Owners
          </h2>
        </div>

        <div className="mt-16 grid gap-8 md:grid-cols-3">
          {testimonials.map((t) => (
            <div key={t.name} className="card p-6">
              <div className="flex gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <p className="mt-4 text-sm text-dark-300 leading-relaxed">
                &ldquo;{t.quote}&rdquo;
              </p>
              <div className="mt-6 border-t border-dark-700 pt-4">
                <p className="text-sm font-semibold text-white">{t.name}</p>
                <p className="text-xs text-dark-400">{t.title}</p>
                <span className="mt-2 inline-block rounded-full bg-brand-500/10 px-2 py-0.5 text-xs text-brand-400">
                  {t.type}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
