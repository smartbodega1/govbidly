"use client";

import Link from "next/link";
import { useState } from "react";
import { SITE_NAME } from "@/lib/constants";
import { Search, Menu, X, Zap } from "lucide-react";

export function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-dark-700 bg-dark-900/80 backdrop-blur-xl">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-600">
              <Zap className="h-5 w-5 text-white" />
            </div>
            <span className="text-lg font-bold text-white">{SITE_NAME}</span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden items-center gap-1 md:flex">
            <Link href="/search" className="btn-ghost">
              <Search className="mr-1.5 h-4 w-4" />
              Search Contracts
            </Link>
            <Link href="/pricing" className="btn-ghost">
              Pricing
            </Link>
            <Link href="/blog" className="btn-ghost">
              Resources
            </Link>
          </nav>

          {/* Auth Buttons */}
          <div className="hidden items-center gap-3 md:flex">
            <Link href="/login" className="btn-ghost">
              Log in
            </Link>
            <Link href="/signup" className="btn-primary !py-2">
              Start Free Trial
            </Link>
          </div>

          {/* Mobile Toggle */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="btn-ghost md:hidden"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

        {/* Mobile Nav */}
        {mobileOpen && (
          <div className="border-t border-dark-700 py-4 md:hidden">
            <nav className="flex flex-col gap-2">
              <Link href="/search" className="btn-ghost justify-start" onClick={() => setMobileOpen(false)}>
                <Search className="mr-2 h-4 w-4" />
                Search Contracts
              </Link>
              <Link href="/pricing" className="btn-ghost justify-start" onClick={() => setMobileOpen(false)}>
                Pricing
              </Link>
              <Link href="/blog" className="btn-ghost justify-start" onClick={() => setMobileOpen(false)}>
                Resources
              </Link>
              <hr className="my-2 border-dark-700" />
              <Link href="/login" className="btn-ghost justify-start" onClick={() => setMobileOpen(false)}>
                Log in
              </Link>
              <Link href="/signup" className="btn-primary" onClick={() => setMobileOpen(false)}>
                Start Free Trial
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
