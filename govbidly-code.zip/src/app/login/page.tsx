import { Metadata } from "next";
import { AuthForm } from "@/components/ui/AuthForm";

export const metadata: Metadata = {
  title: "Log In",
};

export default function LoginPage() {
  return (
    <div className="flex min-h-[calc(100vh-10rem)] items-center justify-center px-4">
      <AuthForm mode="login" />
    </div>
  );
}
