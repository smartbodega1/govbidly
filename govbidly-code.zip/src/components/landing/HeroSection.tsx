"use client";

import Link from "next/link";
import { ArrowRight, Search, Bell, Shield, Star } from "lucide-react";

export function HeroSection() {
  return (
    <section className="relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-brand-950/50 via-dark-900 to-dark-900" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-brand-600/20 via-transparent to-transparent" />

      <div className="relative mx-auto max-w-7xl px-4 pb-20 pt-24 sm:px-6 sm:pt-32 lg:px-8">
        {/* Badge */}
        <div className="flex justify-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-brand-500/30 bg-brand-500/10 px-4 py-1.5 text-sm text-brand-300">
            <Star className="h-3.5 w-3.5 fill-brand-400 text-brand-400" />
            <span>Join 500+ small businesses winning government contracts</span>
          </div>
        </div>

        {/* Headline */}
        <h1 className="mx-auto mt-8 max-w-4xl text-center text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
          Find Government Contracts{" "}
          <span className="gradient-text">Without the Headache</span>
        </h1>

        {/* Subhead */}
        <p className="mx-auto mt-6 max-w-2xl text-center text-lg text-dark-300 sm:text-xl">
          SAM.gov is powerful but painful. We make it simple. Search, filter, and get 
          instant alerts for federal contracts that match your business — in seconds.
        </p>

        {/* CTA Buttons */}
        <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
          <Link href="/signup" className="btn-primary !px-8 !py-4 !text-base group">
            Start Your Free Trial
            <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Link>
          <Link href="/search" className="btn-secondary !px-8 !py-4 !text-base">
            <Search className="mr-2 h-4 w-4" />
            Try a Search
          </Link>
        </div>

        {/* Trust signals */}
        <p className="mt-4 text-center text-sm text-dark-500">
          5-day free trial &bull; No credit card required &bull; Cancel anytime
        </p>

        {/* Stats bar */}
        <div className="mx-auto mt-16 grid max-w-3xl grid-cols-3 gap-8 rounded-2xl border border-dark-700 bg-dark-800/50 p-8 backdrop-blur-sm">
          <div className="text-center">
            <div className="text-3xl font-bold text-white">100K+</div>
            <div className="mt-1 text-sm text-dark-400">Active Contracts</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-white">$1.2T</div>
            <div className="mt-1 text-sm text-dark-400">Annual Federal Spend</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-white">23%</div>
            <div className="mt-1 text-sm text-dark-400">Reserved for Small Biz</div>
          </div>
        </div>

        {/* Mini feature icons */}
        <div className="mx-auto mt-12 flex max-w-2xl flex-wrap items-center justify-center gap-6 text-dark-400">
          <div className="flex items-center gap-2 text-sm">
            <Search className="h-4 w-4 text-brand-400" />
            Smart Search
          </div>
          <div className="flex items-center gap-2 text-sm">
            <Bell className="h-4 w-4 text-brand-400" />
            Email Alerts
          </div>
          <div className="flex items-center gap-2 text-sm">
            <Shield className="h-4 w-4 text-brand-400" />
            Daily Updated
          </div>
        </div>
      </div>
    </section>
  );
}
