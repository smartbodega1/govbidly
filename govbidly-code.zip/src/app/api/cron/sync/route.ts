import { NextRequest, NextResponse } from "next/server";
import { createServiceClient } from "@/lib/supabase/server";
import { fetchSamGovOpportunities, mapSamGovToContract } from "@/lib/sam-gov";

// This endpoint is called by a cron job (e.g., Vercel Cron or external)
// Protected by CRON_SECRET
export async function POST(request: NextRequest) {
  try {
    // Verify cron secret
    const authHeader = request.headers.get("authorization");
    if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const supabase = createServiceClient();

    // Log sync start
    const { data: syncLog } = await supabase
      .from("sync_log")
      .insert({ status: "running" })
      .select()
      .single();

    let totalFetched = 0;
    let totalInserted = 0;
    let totalUpdated = 0;
    let offset = 0;
    const limit = 100;
    const maxRecords = 1000; // Safety limit per sync

    try {
      while (offset < maxRecords) {
        const response = await fetchSamGovOpportunities({
          limit,
          offset,
          postedFrom: getYesterdayFormatted(),
        });

        if (!response.opportunitiesData || response.opportunitiesData.length === 0) {
          break;
        }

        totalFetched += response.opportunitiesData.length;

        // Upsert contracts
        for (const opp of response.opportunitiesData) {
          const contract = mapSamGovToContract(opp);

          const { error } = await supabase
            .from("contracts")
            .upsert(
              {
                ...contract,
                updated_at: new Date().toISOString(),
              },
              { onConflict: "notice_id" }
            );

          if (!error) {
            // We count all as "inserted" since upsert doesn't distinguish
            totalInserted++;
          }
        }

        // Check if we've fetched all available records
        if (offset + limit >= response.totalRecords) {
          break;
        }

        offset += limit;

        // Rate limiting: wait 1 second between requests
        await new Promise((resolve) => setTimeout(resolve, 1000));
      }

      // Update sync log
      if (syncLog) {
        await supabase
          .from("sync_log")
          .update({
            status: "completed",
            completed_at: new Date().toISOString(),
            records_fetched: totalFetched,
            records_inserted: totalInserted,
            records_updated: totalUpdated,
          })
          .eq("id", syncLog.id);
      }

      return NextResponse.json({
        success: true,
        records_fetched: totalFetched,
        records_inserted: totalInserted,
      });
    } catch (syncError: any) {
      // Log failure
      if (syncLog) {
        await supabase
          .from("sync_log")
          .update({
            status: "failed",
            completed_at: new Date().toISOString(),
            error_message: syncError.message,
            records_fetched: totalFetched,
          })
          .eq("id", syncLog.id);
      }
      throw syncError;
    }
  } catch (err: any) {
    console.error("Sync error:", err);
    return NextResponse.json(
      { error: err.message || "Sync failed" },
      { status: 500 }
    );
  }
}

function getYesterdayFormatted(): string {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return `${String(d.getMonth() + 1).padStart(2, "0")}/${String(d.getDate()).padStart(2, "0")}/${d.getFullYear()}`;
}
