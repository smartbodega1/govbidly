import { Metadata } from "next";
import { SearchInterface } from "@/components/search/SearchInterface";

export const metadata: Metadata = {
  title: "Search Government Contracts",
  description:
    "Search and filter federal government contracts from SAM.gov. Find solicitations, pre-solicitations, and awards by NAICS code, state, set-aside type, and more.",
};

export default function SearchPage() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white sm:text-3xl">
          Search Government Contracts
        </h1>
        <p className="mt-2 text-dark-400">
          Find federal contracting opportunities from SAM.gov. Updated daily.
        </p>
      </div>
      <SearchInterface />
    </div>
  );
}
