import { AlertTriangle, Clock, Eye, Frown } from "lucide-react";

const problems = [
  {
    icon: Frown,
    title: "SAM.gov is a Nightmare",
    description:
      "Clunky interface, confusing navigation, and search results that make no sense. You shouldn't need a PhD to find a contract.",
  },
  {
    icon: Clock,
    title: "Hours Wasted Every Week",
    description:
      "Small business owners spend 5-10 hours a week just trying to find relevant opportunities. That's time you could spend actually bidding.",
  },
  {
    icon: Eye,
    title: "You're Missing Opportunities",
    description:
      "By the time you find a contract manually, the deadline might have already passed. Opportunities slip through the cracks daily.",
  },
  {
    icon: AlertTriangle,
    title: "No Smart Alerts",
    description:
      "SAM.gov doesn't proactively notify you about contracts that match your profile. You have to go looking every single time.",
  },
];

export function ProblemSection() {
  return (
    <section className="border-t border-dark-700 bg-dark-950 py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-red-400">
            The Problem
          </p>
          <h2 className="section-heading mt-3">
            Government Contracting Shouldn&apos;t Be This Hard
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-dark-400">
            The federal government spends $700B+ annually on contracts. But finding 
            the right opportunities feels like searching for a needle in a haystack.
          </p>
        </div>

        <div className="mt-16 grid gap-8 sm:grid-cols-2">
          {problems.map((problem) => (
            <div key={problem.title} className="card p-6">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-500/10">
                <problem.icon className="h-5 w-5 text-red-400" />
              </div>
              <h3 className="mt-4 text-lg font-semibold text-white">
                {problem.title}
              </h3>
              <p className="mt-2 text-sm text-dark-400">{problem.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
