import { Metadata } from "next";
import { HeroSection } from "@/components/landing/HeroSection";
import { ProblemSection } from "@/components/landing/ProblemSection";
import { FeaturesSection } from "@/components/landing/FeaturesSection";
import { HowItWorksSection } from "@/components/landing/HowItWorksSection";
import { PricingPreview } from "@/components/landing/PricingPreview";
import { TestimonialsSection } from "@/components/landing/TestimonialsSection";
import { CTASection } from "@/components/landing/CTASection";
import { FAQSection } from "@/components/landing/FAQSection";

export const metadata: Metadata = {
  title: "GovBidly — Find Government Contracts Faster",
  description:
    "Stop wasting hours on SAM.gov. Search, filter, and get alerts for government contracts that match your business. 5-day free trial.",
};

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <ProblemSection />
      <FeaturesSection />
      <HowItWorksSection />
      <PricingPreview />
      <TestimonialsSection />
      <FAQSection />
      <CTASection />
    </>
  );
}
