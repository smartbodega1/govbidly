import { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Calendar } from "lucide-react";

export const metadata: Metadata = {
  title: "Blog — Government Contracting Resources",
  description:
    "Learn how to find and win government contracts. Guides on NAICS codes, set-asides, SAM.gov registration, and small business contracting.",
};

const posts = [
  {
    slug: "how-to-bid-government-contracts",
    title: "How to Bid on Government Contracts: A Complete Beginner's Guide",
    excerpt:
      "Everything you need to know about getting started with government contracting — from SAM.gov registration to submitting your first bid.",
    date: "2026-04-01",
    category: "Getting Started",
    readTime: "12 min",
  },
  {
    slug: "naics-codes-guide",
    title: "NAICS Codes Explained: How to Find the Right Code for Your Business",
    excerpt:
      "NAICS codes determine which contracts you can bid on. Here's how to find yours and use it to win more government work.",
    date: "2026-03-28",
    category: "Guides",
    readTime: "8 min",
  },
  {
    slug: "set-aside-types",
    title: "Set-Aside Contracts: 8(a), HUBZone, SDVOSB, WOSB Explained",
    excerpt:
      "The federal government reserves 23% of contracting dollars for small businesses. Here's how each set-aside program works.",
    date: "2026-03-25",
    category: "Set-Asides",
    readTime: "10 min",
  },
  {
    slug: "sam-gov-registration",
    title: "SAM.gov Registration: Step-by-Step Guide (2026 Updated)",
    excerpt:
      "You can't bid on federal contracts without SAM.gov registration. Follow this step-by-step guide to get registered in under an hour.",
    date: "2026-03-20",
    category: "Getting Started",
    readTime: "7 min",
  },
  {
    slug: "small-business-certifications",
    title: "5 Small Business Certifications That Unlock Government Contracts",
    excerpt:
      "From 8(a) to HUBZone to SDVOSB — these certifications give you a competitive edge in government contracting.",
    date: "2026-03-15",
    category: "Certifications",
    readTime: "9 min",
  },
];

export default function BlogPage() {
  return (
    <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="mb-12">
        <h1 className="text-3xl font-bold text-white sm:text-4xl">
          Government Contracting Resources
        </h1>
        <p className="mt-4 text-lg text-dark-400">
          Guides, tutorials, and insights to help you win government contracts.
        </p>
      </div>

      <div className="space-y-6">
        {posts.map((post) => (
          <Link
            key={post.slug}
            href={`/blog/${post.slug}`}
            className="card-hover block p-6 group"
          >
            <div className="flex items-center gap-3 text-xs text-dark-400">
              <span className="rounded-full bg-brand-500/10 px-2.5 py-0.5 text-brand-400 font-medium">
                {post.category}
              </span>
              <span className="flex items-center gap-1">
                <Calendar className="h-3 w-3" />
                {new Date(post.date).toLocaleDateString("en-US", {
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </span>
              <span>{post.readTime} read</span>
            </div>
            <h2 className="mt-3 text-lg font-semibold text-white group-hover:text-brand-400 transition-colors">
              {post.title}
            </h2>
            <p className="mt-2 text-sm text-dark-400 leading-relaxed">
              {post.excerpt}
            </p>
            <span className="mt-3 inline-flex items-center gap-1 text-sm font-medium text-brand-400 group-hover:text-brand-300">
              Read more
              <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
            </span>
          </Link>
        ))}
      </div>
    </div>
  );
}
