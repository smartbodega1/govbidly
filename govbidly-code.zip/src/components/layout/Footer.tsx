import Link from "next/link";
import { SITE_NAME } from "@/lib/constants";
import { Zap } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t border-dark-700 bg-dark-950">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-8 md:grid-cols-4">
          {/* Brand */}
          <div className="md:col-span-1">
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-600">
                <Zap className="h-5 w-5 text-white" />
              </div>
              <span className="text-lg font-bold text-white">{SITE_NAME}</span>
            </Link>
            <p className="mt-3 text-sm text-dark-400">
              The smarter way to find and win government contracts.
            </p>
          </div>

          {/* Product */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-dark-300">
              Product
            </h3>
            <ul className="mt-4 space-y-2">
              <li><Link href="/search" className="text-sm text-dark-400 hover:text-white transition-colors">Search Contracts</Link></li>
              <li><Link href="/pricing" className="text-sm text-dark-400 hover:text-white transition-colors">Pricing</Link></li>
              <li><Link href="/dashboard" className="text-sm text-dark-400 hover:text-white transition-colors">Dashboard</Link></li>
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-dark-300">
              Resources
            </h3>
            <ul className="mt-4 space-y-2">
              <li><Link href="/blog" className="text-sm text-dark-400 hover:text-white transition-colors">Blog</Link></li>
              <li><Link href="/blog/how-to-bid-government-contracts" className="text-sm text-dark-400 hover:text-white transition-colors">How to Bid</Link></li>
              <li><Link href="/blog/naics-codes-guide" className="text-sm text-dark-400 hover:text-white transition-colors">NAICS Guide</Link></li>
              <li><Link href="/blog/set-aside-types" className="text-sm text-dark-400 hover:text-white transition-colors">Set-Aside Types</Link></li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-dark-300">
              Company
            </h3>
            <ul className="mt-4 space-y-2">
              <li><Link href="/about" className="text-sm text-dark-400 hover:text-white transition-colors">About</Link></li>
              <li><Link href="/contact" className="text-sm text-dark-400 hover:text-white transition-colors">Contact</Link></li>
              <li><Link href="/privacy" className="text-sm text-dark-400 hover:text-white transition-colors">Privacy Policy</Link></li>
              <li><Link href="/terms" className="text-sm text-dark-400 hover:text-white transition-colors">Terms of Service</Link></li>
            </ul>
          </div>
        </div>

        <div className="mt-10 border-t border-dark-800 pt-8">
          <p className="text-center text-sm text-dark-500">
            &copy; {new Date().getFullYear()} {SITE_NAME}. All rights reserved. 
            Data sourced from <a href="https://sam.gov" className="text-dark-400 hover:text-white transition-colors" target="_blank" rel="noopener noreferrer">SAM.gov</a>.
          </p>
        </div>
      </div>
    </footer>
  );
}
